Reporting a bug? Please make sure you've given the following information - thanks!

**Operating system and version:**


**Is this for single player or multiplayer?**


**Description of the bug (and if possible, steps to reproduce the bug):**


**What did you expect to happen instead?**

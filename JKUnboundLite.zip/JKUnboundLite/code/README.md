# OpenJK "Jedi Academy" Singleplayer Code #

This includes code for the SP engine (client+server+ui), SP renderer(s), and the mod code module.